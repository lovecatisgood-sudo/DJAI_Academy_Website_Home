# DJAI Code

Private coding-agent prototype for VS Code and the terminal. DJAI Code connects
one agent workflow to cloud APIs, local models, and the future DJAI Router.

> DJAI Code is not approved for publication or distribution. Review
> [NOTICE-DJAI-CODE.md](NOTICE-DJAI-CODE.md) and [LICENSE](LICENSE) before any
> external release.

## Current prototype

- CLI command: `djai`
- VS Code extension: `vscode-extension/djai-code-vscode`
- Local configuration: `~/.djai`, `.djai/`, and `.djai-profile.json`
- Test provider: DeepSeek through its OpenAI-compatible API
- Future virtual models: DJAI Freemax, DJAI Fast 1.0, and DJAI Max 2

## Requirements

- Node.js 22 or newer
- Bun for source builds
- VS Code 1.95 or newer
- A DeepSeek API key for the current live model test

## Build the CLI

```bash
bun install
bun run build
node bin/djai --version
```

Start an interactive DeepSeek session without saving the key in the repository:

```bash
export DEEPSEEK_API_KEY="your-key"
node bin/djai --provider deepseek --model deepseek-chat
```

For a reasoning session, replace `deepseek-chat` with `deepseek-reasoner`.

## Run in VS Code

Package the extension:

```bash
cd vscode-extension/djai-code-vscode
npx @vscode/vsce package --no-dependencies
code --install-extension djai-vscode-0.2.0.vsix
```

Then configure:

1. Set `djai.launchCommand` to the absolute path of this repository's
   `bin/djai` file.
2. Run **DJAI Code: Configure DeepSeek** from the Command Palette.
3. Enter the endpoint, model, and key. The key is stored in VS Code Secret
   Storage rather than workspace files.
4. Select the DJAI icon in the Activity Bar and open Chat.

The extension starts the existing CLI in streaming JSON mode. Tool execution,
permissions, diffs, sessions, and model output therefore use the same runtime
as terminal sessions.

## Useful checks

```bash
bun run build
bun run typecheck
bun test src/utils/providerFlag.test.ts src/utils/providerValidation.test.ts
cd vscode-extension/djai-code-vscode
bun test src
node scripts/lint.js
```

## Repository layout

- `src/`: CLI and agent runtime
- `bin/djai`: local CLI launcher
- `vscode-extension/djai-code-vscode/`: VS Code companion
- `scripts/`: build and verification tools
- `docs/`: inherited technical reference material under review
- `web/`: documentation site prototype

## Provider architecture

The current DeepSeek connection is temporary validation infrastructure. The
extension calls the CLI using `--provider deepseek`; it does not contain a
separate inference client. This preserves the future migration path:

```text
DJAI Code for VS Code
        ↓
DJAI CLI and agent runtime
        ↓
DeepSeek test API now / DJAI Router later
```

Provider-specific compatibility code remains in the runtime so DJAI Router can
serve multiple model families later. It is not displayed as the DJAI product
identity.

## Release status

No public distribution permission is claimed. The repository-level license and
notice are intentionally preserved even where they contain inherited names or
provenance required for legal review.
